/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServlet.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Dimo
 */
@WebServlet(urlPatterns = {"/welcome"})
public class welcome extends HttpServlet {

    String msg;
    boolean isInitialIteration ;
    private void dealWithInvalidCookie() {
    msg = "Sorry, we do not know each other...<br>"
    + "Please introduce yourself.<br>";
    isInitialIteration = true;
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        isInitialIteration=false;
        // manage params and cookies
        String name = request.getParameter("name");
        String soccerteam = request.getParameter("soccerteam");
        
        if (name != null && ! name.equals("")) {
        // there is the right parameter,
        // no need to read cookie, but we set them
        log("name != null && ! name.equals(\"\")");
        Cookie cookie = new Cookie("name", name);
        msg = "Hi " + name + ", nice to meet you!";
        response.addCookie(cookie); // identity
        Cookie cookie1 = new Cookie("soccerteam", soccerteam);
        response.addCookie(cookie1); // state
        } else {
        // no parameter, let's try with cookies
        Cookie cookies[] = request.getCookies();
        if (cookies==null || cookies.length == 0) {
        // no cookies
        dealWithInvalidCookie();
        } else {
        Cookie n_Cookie=null; 
        Cookie c_Cookie=null; 
        for (Cookie c:cookies) {
        String cookieName = c.getName();
        if (cookieName.equals("name")) {
        n_Cookie=c;
        } else if (cookieName.equals("soccerteam")) {
        c_Cookie=c;
        }
        }
        if (n_Cookie==null) {
        log ("valid cookies not found");
        // invalid cookie
        dealWithInvalidCookie();
        } else {
        // ok, the cookie is good!
        String userName=n_Cookie.getValue();
//        String counterAsString=c_Cookie.getValue();
        log ("name == "+userName);
        // let's update the counter, and the cookie
//        int counter=Integer.valueOf(counterAsString)+1;
//        c_Cookie.setValue(""+counter);
        response.addCookie(c_Cookie);

        }
        }
        
    }}

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void haveCookie(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Cookie cookies[] = request.getCookies();
        Cookie n_Cookie=null; 
        Cookie c_Cookie=null; 
        if (cookies==null || cookies.length == 0) {
        // no cookies
        dealWithInvalidCookie();
        } else {
        for (Cookie c:cookies) {
        String cookieName = c.getName();
        if (cookieName.equals("username")) {
        n_Cookie=c;
        } else if (cookieName.equals("soccerteam")) {
        c_Cookie=c;
                }
            }
        }
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html><body>");
            out.println("<h1> Welcome : "+n_Cookie.getValue()+"</h1>"+"<h2> Your team is : "+c_Cookie.getValue()+"</h2>");
            request.getRequestDispatcher("forgetCookie.html").include(request, response);
            out.println("</body></html>");
        }
    }
    
    protected void normalReq(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String name = request.getParameter("username");
        String soccerteam = request.getParameter("soccerteam");
        Cookie nC = new Cookie("username",name);
        Cookie sC = new Cookie("soccerteam",soccerteam);
        response.addCookie(nC);
        response.addCookie(sC);

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html><body>");
            out.println("<h1> Welcome : "+name+"</h1>"+"<h2> You are a fan of : "+soccerteam+"</h2>");
            request.getRequestDispatcher("forgetCookie.html").include(request, response);
            out.println("</body></html>");
        }
    }
    
    protected void signUp(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html><body>");
            request.getRequestDispatcher("inputForm.html").include(request, response);
            out.println("</body></html>");
        }
    }
    
    /////////////
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nameInput = request.getParameter("username");
        String soccerteam = request.getParameter("soccerteam");
        if(nameInput != null){
            normalReq(request, response);
        }else{
            Cookie cookies[] = request.getCookies();
            if(cookies==null || cookies.length == 0){
                signUp(request, response);
            }
            else{
                haveCookie(request, response);
            }
            
        }
//        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

